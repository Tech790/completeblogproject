from django.shortcuts import render,HttpResponse,reverse
from .models import Categorie,Post,Comment,IpModel
from django.http import JsonResponse
from django.contrib import messages
from django.core import serializers
from django.utils import timezone
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponseRedirect


# Create your views here.
def home(request):
	# ip = request.META.get('REMOTE_ADDR')
	# request.session['ip'] = ip
	# print(ip)
	now = timezone.now()
	categorie = Categorie.objects.filter(date__lte=now)
	# print(categorie)
	return render(request,'blogapp/home.html',{'categorie':categorie})

def single_post(request,id):
	all_cats = Categorie.objects.all()
	cats = Categorie.objects.get(pk=id)
	posts_of_cats = Post.objects.filter(cat=cats)
	return render(request,'blogapp/single_post.html',
		{'posts':posts_of_cats,'all_cats':all_cats})


        
        
        



def post_details(request,id):
	post = Post.objects.get(id=id)
	comments = Comment.objects.filter(post=post)
	cat = Post.objects.filter(cat=post.cat)
	like_status = False
	ip = get_client_ip(request)
	if post.like.filter(id=IpModel.objects.get(ip=ip).id).exists():
		like_status = True
	else:
		like_status=False
        
	return render(request,'blogapp/post_details.html',
		{'post':post,'cat':cat,'comments':comments,'like_status':like_status})

def comment(request):
	if request.method == 'POST':
		comment = request.POST.get('comment')
		post_id = request.POST.get('post')
		post = Post.objects.get(id=post_id)
		save_comment = Comment(comment=comment,
			post=post)
		save_comment.save()
		# messages.success(request,'Comment Submitted Successfully')
		comments = Comment.objects.filter(post=post)
		data_comment = serializers.serialize("json",comments)
		return JsonResponse({'status':1,'comments':data_comment})
	else:
		return JsonResponse({'status':0})

def get_client_ip(request):
    x_forwarded_for = request.META.get('HTTP_X_FORWARDED_FOR')
    if x_forwarded_for:
        ip = x_forwarded_for.split(',')[0]
    else:
        ip = request.META.get('REMOTE_ADDR')
    return ip


@csrf_exempt
def like_post(request):
	post_id = request.POST.get('btn_id')
	post = Post.objects.get(pk=post_id)
	ip = get_client_ip(request)
	if not IpModel.objects.filter(ip=ip).exists():
	    IpModel.objects.create(ip=ip)
	if post.like.filter(id=IpModel.objects.get(ip=ip).id).exists():
	    post.like.remove(IpModel.objects.get(ip=ip))
	else:
	    liked = post.like.add(IpModel.objects.get(ip=ip))
	    liked = post.like.count()
	    btn_active = 'Unlike'
	    return JsonResponse({'status':1,'liked':liked,
	    	'btn_active':btn_active})
	liked = post.like.count()
	btn_active = 'like'
	return JsonResponse({'status':0,'liked':liked,
		'btn_active':btn_active})
	# return HttpResponseRedirect(reverse('post_detail', args=[post_id]))

	# ip = request.META.get('REMOTE_ADDR')
	# request.session['ip'] = ip
	# print(ip)
	# btn_id = request.POST.get('btn_id')
	# post_to_like = Post.objects.get(id=btn_id)
	# post_to_like.like += 1
	# post_to_like.save()
	# liked = post_to_like.like
	# return JsonResponse({'status':1,'liked':liked})

# @csrf_exempt
# def dislike_post(request):
# 	btn_id = request.POST.get('btn_id')
# 	post_to_dislike = Post.objects.get(id=btn_id)
# 	post_to_dislike.dislike += 1
# 	post_to_dislike.save()
# 	disliked = post_to_dislike.dislike
# 	return JsonResponse({'status':1,'disliked':disliked})