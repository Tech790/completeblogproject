from django.contrib import admin
from .models import (
Categorie,Post,Comment,IpModel
	)
# Register your models here.

@admin.register(Categorie)
class CategorieAdmin(admin.ModelAdmin):
	list_display = ['id','name']


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
	list_display = ['id','title','read']


@admin.register(Comment)
class CommentAdmin(admin.ModelAdmin):
	list_display = ['id','comment']


@admin.register(IpModel)
class IpModelAdmin(admin.ModelAdmin):
	list_display = ['id','ip']