from django.contrib import admin
from django.urls import path
from blogapp import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.home,name='home'),
    path('single_post/<int:id>/',views.single_post,name='single_post'),
    path('post_detail/<int:id>/',views.post_details,name='post_detail'),
    path('comment/',views.comment,name='comment'),
    path('like_post/',views.like_post,name='like_post'),
    # path('dislike_post/',views.dislike_post,name='dislike_post'),

] + static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
